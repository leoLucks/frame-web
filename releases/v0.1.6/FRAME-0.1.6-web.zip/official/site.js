(() => {
  const status = document.querySelector('[data-release-status]');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  fetch('../updates/stable.json?check=' + Date.now(), {cache:'no-store',credentials:'omit',redirect:'error',signal:controller.signal})
    .then(response => { if(!response.ok) throw new Error('unavailable'); return response.json(); })
    .then(manifest => {
      const release = manifest && manifest.android;
      if(manifest.schemaVersion!==1 || manifest.appId!=='studio.frame.nikon' || manifest.channel!=='stable' || !release || !/^(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})$/.test(release.version)) throw new Error('invalid');
      const repo='https://github.com/leoLucks/frame-web';
      const url=repo+'/releases/download/v'+release.version+'/FRAME-'+release.version+'-android.apk';
      const notesUrl=repo+'/releases/tag/v'+release.version;
      if(release.url!==url || manifest.releaseUrl!==notesUrl || !/^[a-f0-9]{64}$/.test(release.sha256) || !Number.isSafeInteger(release.sizeBytes) || release.sizeBytes<=0 || release.sizeBytes>150*1024*1024 || !Array.isArray(release.notes) || release.notes.length<1 || release.notes.length>20 || release.notes.some(note=>typeof note!=='string'||!note.trim()||note.length>240)) throw new Error('invalid');
      document.querySelectorAll('[data-version]').forEach(element=>{element.textContent='v'+release.version;});
      document.querySelectorAll('[data-download]').forEach(element=>{element.href=url;});
      document.querySelectorAll('[data-release]').forEach(element=>{element.href=notesUrl;});
      document.querySelector('[data-package-size]').textContent=(release.sizeBytes/1024/1024).toFixed(1)+' MB · 下载后按系统提示安装';
      const published=new Date(manifest.publishedAt);if(Number.isFinite(published.getTime())) document.querySelector('[data-published]').textContent=new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(published).replaceAll('/',' / ');
      document.querySelector('[data-notes]').replaceChildren(...release.notes.map(note=>{const li=document.createElement('li');li.textContent=note;return li;}));
      status.textContent='已连接版本服务 · 安装包提供 SHA-256 校验';
    })
    .catch(()=>{status.textContent='暂未读取到最新版本信息，当前下载入口仍可用；请在 GitHub 查看完整版本记录。';})
    .finally(()=>clearTimeout(timer));
})();
